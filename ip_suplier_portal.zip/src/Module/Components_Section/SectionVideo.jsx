import React from 'react'
import Grid from '@material-ui/core/Grid'
import { makeStyles } from '@material-ui/core/styles';


const useStyles = makeStyles((theme) => ({
    outrContainer: {
    marginTop: theme.spacing(7),
  
  },
  
  responsiveIframe:
  {
    top: 0,
    left: 0,
    width: "100%",
    height: "400px",
    border: 0,
	objectFit: "contain",
  }
  
  }));
    



export default function SectionVideo() {
    const classes = useStyles();
    return (
        <div>
            <Grid
              container
              spacing={2}
              direction="row"
              justify="flex-start"
              alignItems="flex-start"
              alignContent="stretch"
              wrap="nowrap"
              
            >
              <Grid  xs={12} md={12} sm={12}>

               <div>
                <iframe className={classes.responsiveIframe} src="https://www.youtube.com/embed/3xzJpizAU3A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
               </div> 

              </Grid>
            </Grid>
        </div>
    )
}

import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container'
import Typography from '@material-ui/core/Typography'
import Grid from '@material-ui/core/Grid'


import iconimage1 from "../../assects/image/Iconimage/goods_icon.png";
import iconimage2 from "../../assects/image/Iconimage/payment_icon_6.png";
import iconimage3 from "../../assects/image/Iconimage/person_icon_3.png";



const useStyles = makeStyles((theme) => ({
    DescriptionContainer: {
    padding: theme.spacing(3),
   
  
  },
  
  IconImagePortion:
  {
    width:"4em",
    height:"4em",
    objectFit:"cover",
    overflow:"hidden"
  
  }
  
  }));
    


export default function SectionDescription() {

    const classes = useStyles();
    return (

        
        <div>
            <Container maxWidth="lg" className={classes.DescriptionContainer}>
               <Grid container spacing={3}>
                    <Grid item xs={12}sm={12} md={12} align='center'>
                      <Typography variant="h6" color="initial">Ease of handling one customer - MindKorp</Typography>
                    <Typography variant='subtitle1' gutterBottom>Digiswaraj will bring you sales, manage your distribution and deliver headache free timely payment</Typography>
                    </Grid>
               </Grid>

                <Grid container spacing={3}>
                    <Grid item xs={12}sm={12} md={4} align='center'>
                          <img src={iconimage1} alt=""  className={classes.IconImagePortion}/>
                           <Typography variant="subtitle1" display="block" gutterBottom>
                                caption text
                            </Typography>
                     </Grid>   
                    <Grid item xs={12}sm={12} md={4} align='center'>
                         <img src={iconimage2} alt="" className={classes.IconImagePortion} />
                         <Typography variant="subtitle1" display="block" gutterBottom>
                            caption text
                        </Typography>
                    </Grid>   

                     <Grid item xs={12}sm={12} md={4} align='center'>
                         <img src={iconimage3} alt=""  className={classes.IconImagePortion} />
                         <Typography variant="subtitle1" display="block" gutterBottom>
                            caption text
                        </Typography> 
                    </Grid>                    
                </Grid>
            </Container>
        </div>
    )
}

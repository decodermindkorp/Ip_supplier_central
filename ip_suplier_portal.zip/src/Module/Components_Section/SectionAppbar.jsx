import React from 'react';
import { Link } from "react-router-dom";
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid'


const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 0,

  },
  link:
  {
    textDecoration:"none",
    marginRight: theme.spacing(2),
  },
  header:
  {
    
      backgroundColor:'white',
      color:'black'
  },
 
  title: {
    flexGrow: 1,
  },
  menuButton: {
  
    marginRight: theme.spacing(2),
    textTransform:"lowercase",
  },
 
}));

export default function SectionAppbar() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
        <AppBar position="fixed"  className={classes.header}>
        <Toolbar>
          <Typography variant="h6" className={classes.title}>
            MINDKORP
          </Typography>
          <Link to={"/Signup"} className={classes.link} variant="subtitle2">
                Sign in
            </Link>
              <span className={classes.bar}></span>
              <Link to={"/Login"} className={classes.link}  variant="subtitle2">
                 Sign Up
             </Link>
            <Button variant="outlined" color="primary" >
            Register Now
         </Button>
        </Toolbar>
      </AppBar> 
        </Grid>
      </Grid>
     
    </div>
  );
}

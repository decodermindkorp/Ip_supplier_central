import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container'
import Grid from '@material-ui/core/Grid'
import Typography from '@material-ui/core/Typography'
import iconimage1 from '../../assects/image/Iconimage/gallery_icon.png'



const useStyles = makeStyles((theme) => ({
    ReturnPolicyContainer: {
    padding: theme.spacing(3),
   
  
  },
  
  IconImagePortion:
  {
    width:"4em",
    height:"4em",
    objectFit:"cover",
    overflow:"hidden"
  
  }
  
  }));
export default function SectionReturnPolicy() {
    const classes = useStyles();
    return (
        <div>
            <Container maxWidth="md" className={classes.ReturnPolicyContainer}>
              <Grid
                container
                spacing={1}
                direction="row"
                justify="center"
                alignItems="center"
                alignContent="center"
                wrap="nowrap"
                
              >
                    <Grid item xs={12}sm={12} md={12} align='center'>
                        <img src={iconimage1} className={classes.IconImagePortion} alt="" />
                      <Typography variant="h5" color="initial">Return policies</Typography>
                    <Typography variant='body1' gutterBottom className={classes.ReturnPolicyContainer}>Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                          Nunc ullamcorper condimentum ultrices.  Cras euismod ornare laoreet.
                           Quisque vel efficitur quam, eu molestie odio.In hac habitasse platea dictumst.
                        Integer diam sapien, aliquet sit amet feugiat vel, tempor nec leo.
                     </Typography>
                    </Grid>
  
              </Grid>
            </Container>
        </div>
    )
}

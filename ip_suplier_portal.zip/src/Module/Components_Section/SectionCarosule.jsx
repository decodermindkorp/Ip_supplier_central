import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Carousel from 'react-material-ui-carousel'
import { Paper, Button, Grid } from '@material-ui/core'


import image1 from "../../assects/image/SlideImage/slide_2.jpeg";
import image2 from "../../assects/image/SlideImage/sli_1.png";    
import image3 from "../../assects/image/SlideImage/slider_3.jpg";


const useStyles = makeStyles((theme) => ({
  outrContainer: {
  marginTop: theme.spacing(7),

},

ImagePortion:
{
  width:"100%",
  height:"400px",
  objectFit:"cover",
  overflow:"hidden",


}

}));

export default function SectionCarosule(props)
{
  
    var items = [
        {
          
           
            image: image1,
        },
        {
           
            image: image2,
        },
        {
           
          image: image3,
      }

    ]

    return (
       

      
        <Carousel>
            {  
                items.map( (item, i) => <Item item={item} /> )
            }
        </Carousel>
        
        
    )
}

function Item(props)
{
  const classes = useStyles();
    return (

        <div>
        <Grid
           container
           spacing={1}
           direction="row"
           justify="flex-start"
           alignItems="flex-start"
           alignContent="stretch"
           wrap="nowrap"
           
         >
          <Grid item xs={12}sm={12} md={12} >
             <div className={classes.outrContainer} >
                <img  className={classes.ImagePortion} src={props.item.image} alt="" />
                <h2>{props.item.name}</h2>
             </div>
           
            </Grid>
          </Grid>

        
           
         
      
        </div>
    )
}
import React from 'react'
import { Grid,Paper, Avatar, TextField, Button, Typography,Link } from '@material-ui/core'
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { makeStyles } from '@material-ui/core/styles';




const useStyles = makeStyles((theme) => ({
  
     root:
     {
         padding:theme.spacing(4),
      
     },
  
   
  }));


const Login=({handleChange})=>{

    const paperStyle={padding :20,height:'73vh',width:350, margin:"0 auto"}
    const avatarStyle={backgroundColor:'#1bbd7e'}
    const btnstyle={margin:'8px 0'}
    const classes = useStyles();
    return(
        <Grid className={classes.root}>
            <Paper  style={paperStyle} >
                <Grid align='center' >
                     <Avatar style={avatarStyle}><LockOutlinedIcon/></Avatar>
                   
                    <h2>MINDKORP</h2>
                    <h4>Sign in</h4>
                    {/* <Button type='submit' color='default' variant="contained" style={btnstyle} fullWidth>Sign in with Google</Button> */}
                    <Button variant="outlined" type='submit' style={btnstyle} color="default" fullWidth>
                    Sign in with Google
                    </Button>
                </Grid>
                <TextField label='Continue with Email/Phone' placeholder='Enter username' fullWidth required/>
                <TextField label='Password' placeholder='Enter password' type='password' fullWidth required/>
                <FormControlLabel
                    control={
                    <Checkbox
                        name="checkedB"
                        color="primary"
                    />
                    }
                    label="Remember me"
                 />
                <Button type='submit' color='primary' variant="contained" style={btnstyle} fullWidth>Sign in</Button>
                <Typography >
                     <Link href="#" >
                        Forgot password ?
                </Link>
                </Typography>
                <Typography > Do you have an account ?
                     <Link href="#" onClick={()=>handleChange("event",1)} >
                        Sign Up 
                </Link>
                </Typography>
            </Paper>
        </Grid>
    )
}

export default Login
import React from 'react'
import SectionAppbar from '../Components_Section/SectionAppbar'
import SectionCarosule from '../Components_Section/SectionCarosule'
import SectionDescription from '../Components_Section/SectionDescription'
import SectionFooter from '../Components_Section/SectionFooter'
import SectionGallery from '../Components_Section/SectionGallery'
import SectionReturnPolicy from '../Components_Section/SectionReturnPolicy'
import SectionVideo from '../Components_Section/SectionVideo'





export default function Home() {
   
  
    return (
        <div >
            <SectionAppbar/>
            <SectionCarosule/>
            <SectionDescription/>   
            <SectionVideo/>
            <SectionReturnPolicy/>
            <SectionGallery/>
            <SectionFooter/>
        </div>
    )
}

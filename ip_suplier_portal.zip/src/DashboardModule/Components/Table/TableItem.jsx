import * as React from 'react';
import { DataGrid } from '@material-ui/data-grid';
import { Grid, Typography } from '@material-ui/core';
import DeleteIcon from '@material-ui/icons/Delete';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
   
  },
}));
const columns = [
  { field: 'Date', headerName: 'Date', width: 120 },
  { field: 'Dono', headerName: 'DO No', width: 100 },
  { field: 'items', headerName: 'Items', width: 100 },
  {
    field: 'value',
    headerName: 'Value',
    type: 'number',
    width: 90,
  },
  {
    field: 'Deliveredby',
    headerName: 'Delivered By',
    width: 150,
  },
  {
    field: 'action', headerName: 'Action', width: 100 

  },
];

			
const rows = [
  { id: 1, Date:"21/01/2021", Dono: 'DO/001', items: 'ALC01', value: 3500, Deliveredby:"21/01/2021", action : "Del"},
  { id: 2, Date:"21/01/2021", Dono: 'DO/002', items: 'ALC02', value: 3512, Deliveredby:"21/01/2021", action : "Del"},
  { id: 3, Date:"21/01/2021", Dono: 'DO/003', items: 'ALC03', value: 4335, Deliveredby:"21/01/2021", action : "Del"},
  { id: 4, Date:"21/01/2021", Dono: 'DO/004', items: 'ALC04', value: 1235, Deliveredby:"21/01/2021", action : "Del"},
  { id: 5, Date:"21/01/2021", Dono: 'DO/005', items: 'ALC05', value: 3455, Deliveredby:"21/01/2021", action : "Del"},
  { id: 5, Date:"21/01/2021", Dono: 'DO/005', items: 'ALC05', value: 3455, Deliveredby:"21/01/2021", action : "Del"},
  { id: 5, Date:"21/01/2021", Dono: 'DO/005', items: 'ALC05', value: 3455, Deliveredby:"21/01/2021", action : "Del"},
  { id: 5, Date:"21/01/2021", Dono: 'DO/005', items: 'ALC05', value: 3455, Deliveredby:"21/01/2021", action : "Del"},
 
];


const Secondcolumns = [
  { field: 'InvDt', headerName: 'Inv Dt', width: 120 },
  { field: 'InvNo', headerName: 'Inv No', width: 100 },
  { field: 'InvAmt', headerName: 'Inv Amt',type: 'number', width: 110 },
  {
    field: 'paymentamt',
    headerName: 'Pay Amt',
    type: 'number',
    width: 110,
  },
  {
    field: 'pendingAmt',
    headerName: 'Pending Amt',
    type: 'number',
    width: 150,
  },
 
];
			
const secondrows = [
  { id: 1, InvDt:"21/01/2021", InvNo: 'DO/001', InvAmt: 'ALC01', paymentamt: 3500, pendingAmt: 100,},
  { id: 2, InvDt:"21/01/2021", InvNo: 'DO/002', InvAmt: 'ALC02', paymentamt: 3512, pendingAmt: 200, },
  { id: 3, InvDt:"21/01/2021", InvNo: 'DO/003', InvAmt: 'ALC03', paymentamt: 4335, pendingAmt: 300, },
  { id: 4, InvDt:"21/01/2021", InvNo: 'DO/004', InvAmt: 'ALC04', paymentamt: 1235, pendingAmt: 400,},
  { id: 5, InvDt:"21/01/2021", InvNo: 'DO/005', InvAmt: 'ALC05', paymentamt: 3455, pendingAmt: 500, },
 
];


export default function TableItem() {
  const classes = useStyles();
  return (

    <Grid container spacing={3}>
         
    <Grid item md={6} sm={12} xs={12} >
        <Paper className={classes.paper}>
          <Typography variant="subtitle1" color="initial" align="left">Pending Delivery Orders</Typography>
        <div style={{ height: 300, width: '100%' , backgroundColor:"white"}}>
          
          <DataGrid rows={rows} columns={columns} pageSize={5}  />
        </div>
        </Paper>
   
  </Grid>

  <Grid item md={6} sm={12} xs={12}>
     <Paper className={classes.paper}>
        <Typography variant="subtitle1" color="initial" align="left">Outstanding Amount</Typography>
      <div style={{ height: 300, width: '100%', backgroundColor:"white" }}>
      
       <DataGrid rows={secondrows} columns={Secondcolumns} pageSize={5}  />
     </div>
     </Paper>
  </Grid>

</Grid>
  );
}

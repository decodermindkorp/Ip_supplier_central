import React from "react";
import Divider from '@material-ui/core/Divider';
import {
  Drawer as MUIDrawer,
  ListItem,
  List,
  ListItemIcon,
  ListItemText
} from "@material-ui/core";


import MailIcon from "@material-ui/icons/Mail";
import PaymentIcon from '@material-ui/icons/Payment';
import CreditCardIcon from '@material-ui/icons/CreditCard';
import PersonAddIcon from '@material-ui/icons/PersonAdd';
import PowerSettingsNewIcon from '@material-ui/icons/PowerSettingsNew';
import AssignmentIcon from '@material-ui/icons/Assignment';
import DescriptionIcon from '@material-ui/icons/Description';
import ReceiptIcon from '@material-ui/icons/Receipt';
import LocalShippingIcon from '@material-ui/icons/LocalShipping';
import AccountBalanceWalletIcon from '@material-ui/icons/AccountBalanceWallet';
import ListAltIcon from '@material-ui/icons/ListAlt';

export default function SampleListItem(props)
{
  const { history } = props;

  const itemsList = [
    {
      text: "RFQ",
      icon: <AssignmentIcon />,
      onClick: () => {}
    },
    {
      text: "QTN",
      icon: <DescriptionIcon />,
      onClick: () =>{}
    },
    {
      text: "PO",
      icon: <ListAltIcon />,
      onClick: () =>{}
    }
    ,
    {
      text: "DO",
      icon: <LocalShippingIcon />,
      onClick: () =>{}
    },
    {
      text: "Invoice",
      icon: <ReceiptIcon />,
      onClick: () =>{}
    },
    {
      text: "Payment",
      icon: <AccountBalanceWalletIcon />,
      onClick: () =>{}
    },
    {
      text: "CRN",
      icon: <PaymentIcon/>,
      onClick: () =>{}
    },
    {
      text: "DBN",
      icon: <CreditCardIcon/>,
      onClick: () =>{}
    },
    {
      text: "Manage Profile",
      icon: <PersonAddIcon />,
      onClick: () =>{}
    },
    {
      text: "Sign Out",
      icon: <PowerSettingsNewIcon />,
      onClick: () =>{}
    }
  ];

   return(
          <div>
               <Divider />
             <List>
                {itemsList.map((item, index) => {
                const { text, icon, onClick } = item;
                return (
                    <ListItem button key={text} onClick={onClick}>
                    {icon && <ListItemIcon>{icon}</ListItemIcon>}
                    <ListItemText primary={text} />
                    </ListItem>
                );
                })}
            </List>
            <Divider />
        </div>
      

   );
}


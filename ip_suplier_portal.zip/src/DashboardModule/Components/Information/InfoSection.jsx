import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import Avatar from '@material-ui/core/Avatar';
import { red } from '@material-ui/core/colors';
import Grid from '@material-ui/core/Grid';

// for icon import 
import PaymentIcon from '@material-ui/icons/Payment';
import CreditCardIcon from '@material-ui/icons/CreditCard';
import PersonAddIcon from '@material-ui/icons/PersonAdd';
import PowerSettingsNewIcon from '@material-ui/icons/PowerSettingsNew';
import AssignmentIcon from '@material-ui/icons/Assignment';
import DescriptionIcon from '@material-ui/icons/Description';
import ReceiptIcon from '@material-ui/icons/Receipt';
import LocalShippingIcon from '@material-ui/icons/LocalShipping';
import AccountBalanceWalletIcon from '@material-ui/icons/AccountBalanceWallet';
import ListAltIcon from '@material-ui/icons/ListAlt';



const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 400,
    height:70,
    textAlign:"center"
  },
 
 
  avatar: {
    backgroundColor: red[700],
    padding: theme.spacing(2)
  },
}));

export default function InfoSection() {
  const classes = useStyles();
 
  
  const itemsList = [
    {
      text: "RFQ",
      icon: <AssignmentIcon />,
      remark: 5
    },
    {
      text: "QUOTATION",
      icon: <DescriptionIcon />,
      remark: 6
    },
    {
      text: "PURCHASE ORDER",
      icon: <ListAltIcon />,
      remark: 7
    }
    ,
    {
      text: "DELIVERY ORDER",
      icon: <LocalShippingIcon />,
      remark: 8
    },
    {
      text: "Invoice",
      icon: <ReceiptIcon />,
      remark: 9
    },
    {
      text: "PAYMENT",
      icon: <AccountBalanceWalletIcon />,
      remark: 2
    },
    {
      text: "CREDIT NOTE",
      icon: <PaymentIcon/>,
      remark: 1
    },
    {
      text: "DEBIT NOTE",
      icon: <CreditCardIcon/>,
      remark: 3
    },

  ];

  return (
        <Grid container spacing={3}>
            {itemsList.map((item,index)=>{
                 const { text, icon, remark } = item;
                 return(
                  <Grid item md={6} lg={3} sm={6} xs={12} align="center">
                  <Card className={classes.root}>
                    <CardHeader
                   
                      avatar={
                        <Avatar aria-label="recipe" className={classes.avatar}>
                          {icon}
                        </Avatar>
                    }  
                    title={text}
                    subheader={remark}
                    />
 
                    </Card>
                </Grid>

                 )
              

                  })}
        </Grid>
  );
}

import React from 'react';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Topbar from "../Components/Topbar/Topbar";
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import Link from '@material-ui/core/Link';
import Typography from '@material-ui/core/Typography';
import TableItem from "../Components/Table/TableItem";
import InfoSection from '../Components/Information/InfoSection';
import BarChart from "../Components/Chart/BarChart"
import LineChart from '../Components/Chart/LineChart';
// import DataTableItem from '../Components/Table/DataTableItem';

  

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    backgroundColor:
    theme.palette.type === 'light' ? theme.palette.grey[50] : theme.palette.grey[100],
  },
 
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
 
}));


function Copyright() {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {'Copyright © '}
      <Link color="inherit" href="mindkorp.com">
        MINDKORP
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

export default function MiniDrawer() {
  const classes = useStyles();
 
  return (
    <div className={classes.root}>
      <CssBaseline />
     
      <Topbar/>
      <main className={classes.content}>
        <div className={classes.toolbar} />
      
             <Grid container spacing={3}>
                        
                <Grid item xs={12} md={12} lg={12}>

                  <InfoSection/>
                </Grid>

            </Grid>

          <Grid container spacing={3}>
            
            <Grid item xs={12} md={12} lg={12} >
            
               <TableItem/>
            </Grid>

          </Grid>

          {/* <Grid container spacing={3}>
            
            <Grid item xs={12} md={12} lg={12} >
            
            <DataTableItem/>
            </Grid>

          </Grid> */}


          <Grid container spacing={3}>
            
              <Grid item xs={12} md={6} lg={6}>
                  <BarChart/>
                
              </Grid>


              <Grid item xs={12} md={6} lg={6}>
                  <LineChart/> 
              </Grid>

           </Grid>

          <Box pt={4}>
            <Copyright />
          </Box>
      

      </main>
    </div>
  );
}

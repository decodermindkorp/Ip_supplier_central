import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, Switch } from "react-router-dom";

// import App from './App';

// pages for this product
import Home from "./Module/Views/Home";
import Signup from "./Module/Views/Signup.jsx";
import Login from "./Module/Views/Login.jsx";
import Dashbord from "./DashboardModule/Pages/DashbordPage.jsx";



import { createBrowserHistory } from "history";
var hist = createBrowserHistory();
ReactDOM.render(
 
  <Router history={hist}>  
  <Switch>
    <Route path="/Signup" component={Signup} />
    <Route path="/Login" component={Login} />
    <Route path="/Dashbord" component={Dashbord} />
    
    
    <Route path="/" component={Home} />
    
    

  </Switch>
</Router>,

  document.getElementById('root')
);



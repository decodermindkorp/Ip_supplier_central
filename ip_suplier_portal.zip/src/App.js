import Dashboard from "./DashboardModule/Pages/DashbordPage";
import Home from "./Module/Views/Home";
import Login from "./Module/Views/Login";
import Signup from "./Module/Views/Signup";


function App() {
  return (
    <div className="App">
     {/* <Home/> */}
     <Dashboard/>
     
    </div>
  );
}

export default App;
